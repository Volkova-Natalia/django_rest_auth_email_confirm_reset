from .base import BaseViewsTestCase

from .registration import BaseRegistrationViewsTestCase
from .login import BaseLoginViewsTestCase
from .logout import BaseLogoutViewsTestCase
from .auth_info import BaseAuthInfoViewsTestCase

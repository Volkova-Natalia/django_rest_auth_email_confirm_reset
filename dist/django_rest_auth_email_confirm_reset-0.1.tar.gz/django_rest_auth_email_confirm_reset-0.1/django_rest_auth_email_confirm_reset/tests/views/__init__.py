from .common import CommonViewsTestCase

from .registration import RegistrationViewsTestCase
from .login import LoginViewsTestCase
from .logout import LogoutViewsTestCase
from .auth_info import AuthInfoViewsTestCase

from django.apps import AppConfig


class DjangoRestAuthEmailConfirmResetConfig(AppConfig):
    name = 'django_rest_auth_email_confirm_reset'

from django.contrib.auth.tokens import PasswordResetTokenGenerator


class ConfirmationTokenGenerator(PasswordResetTokenGenerator):
    pass


user_email_confirmation_token = ConfirmationTokenGenerator()
user_email_password_reset_token = PasswordResetTokenGenerator()
